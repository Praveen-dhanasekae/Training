package com.pms.service;

import com.pms.Entities.Payment;
import com.pms.Entities.PaymentObject;
import com.pms.Entities.PolicyPaymentDisplay;

public interface PaymentServiceInterface {

	PolicyPaymentDisplay generateBill(PaymentObject obj);

}