
package com.pms.service;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pms.Entities.Mainuser;
import com.pms.Entities.Payment;
import com.pms.Entities.PaymentObject;
import com.pms.Entities.PolicyPaymentDisplay;
import com.pms.Entities.PolicyTable;
import com.pms.dao.MainDataRepo;
import com.pms.dao.PaymentAcessDao;
import com.pms.dao.PolicyDataRepo;

@Service
public class PaymentService implements PaymentServiceInterface {
@Autowired
PaymentAcessDao  pad;
@Autowired
PolicyDataRepo dao2;

Payment payment ;
@Autowired
PolicyPaymentDisplay pd;
PolicyTable pinfo;
LocalDate ld ;
String  policyName=null;
Mainuser u;
@Autowired
MainDataRepo uad;
@Override
public PolicyPaymentDisplay generateBill(PaymentObject obj) {

    payment= pad.findByName(obj.getUser(),obj.getPolicy());
    System.out.print(obj.getPolicy()+"gskdhsb");
 /*   System.out.println(payment.getBillId());
    System.out.println(payment.getBillDate());
    System.out.println(payment.getDueDate());
    System.out.println(payment.getFine());
    System.out.println(payment.getUser());*/
    
    policyName=dao2.getpolicyname(obj.getPolicy());
    System.out.println(policyName);
    pd.setPolicyId(obj.getPolicy());
    pd.setPolicyName(policyName);
    ld =java.time.LocalDate.now(); 
    pd.setCurrentDate(ld);
    pd.setUserId(obj.getUser());
    pinfo=dao2.findByPolicyId(obj.getPolicy());
    System.out.println(pinfo.getTermAmount());
    if(payment==null) {
    	pd.setFine(0);
    	System.out.println(pinfo.getTermAmount());
    	pd.setAmount(pinfo.getIntialDeposit()+pinfo.getTermAmount());
    	pd.setDueDate(ld.plusMonths((long)pinfo.getTermsPerYear()));
    	return pd;
    }  
    
    else {
    	
    	
    	if(ld.isBefore(payment.getDueDate())||(ld.compareTo(payment.getDueDate())==0)) {
    		pd.setFine(0);
    		pd.setAmount(pinfo.getTermAmount());
    		pd.setDueDate(payment.getDueDate().plusMonths((long)pinfo.getTermsPerYear()));
    		
    	}
    	else {
    		System.out.println("Hello Maven");
    		LocalDate d1 = payment.getDueDate();
    		LocalDate d2=d1;
    		while(d1.isBefore(ld)) {
    			d1=d1.plusMonths((long)pinfo.getTermsPerYear());
    		}
    		long daysBetween = java.time.temporal.ChronoUnit.DAYS.between(ld, d2);
    		System.out.println(daysBetween);
    		String polId=obj.getPolicy();
    		String[] a = polId.split("-",-2);
    		System.out.println(a[1]);
    		double finepercent=0;
    		 switch(a[1]) {
    		 case "VL":finepercent=5;
    		 			break;
    		 case "TI":finepercent=4.5;
    		 			break;
    		 case "LI":finepercent=4;
    		 			break;
    		 case "HI":finepercent=4;
    		 			break;
    		 case "CP":finepercent=4.75;
	 			break;
    		 case "RP":finepercent=2.5;
	 			break;
    		 
    		 }
    		 System.out.println(finepercent);
    		
    		 
    		double fine = (finepercent*pinfo.getTermAmount())/100;
    		double amtToPay=fine*Math.abs(daysBetween)+pinfo.getTermAmount();
    		pd.setAmount(amtToPay);
    		pd.setFine(fine);
    		pd.setDueDate(d1);
    		
    	}
    	return pd;
    }
    
}
public String sucessMsg(PolicyPaymentDisplay ppd) {
	 
	String billId=pad.findLatestBill();
	String a[]= billId.split("-",-3);
	
	int p =Integer.parseInt(a[a.length-1]);
	p=p+1;
	String wfof=null;
	if(ppd.getFine()==0)
	{
		wfof="ON";
	}
	else
		wfof="WF";
	billId=ppd.getPolicyId()+"-"+wfof+"-"+String.format("%03d", p);
	
	
	System.out.println(billId);
	
	Mainuser user=uad.findByUserid(ppd.getUserId());
	System.out.println(user.getFirstName());
	
	//pad.insertNewBill(ppd.getCurrentDate(),ps.getBillId(),ppd.getDueDate(),ppd.getFine(),ppd.getAmount(),user);
	if(payment==null) {
		payment=new Payment();
	}
	payment.setBillId(billId);
	payment.setBillDate(ppd.getCurrentDate());
	payment.setDueDate(ppd.getDueDate());
	payment.setFine(ppd.getFine());
	payment.setPaidAmt(ppd.getAmount());
	payment.setUser(user);
	pad.save(payment);
	return "Payment Sucessfull.Your Bill Id is "+billId+"Next DueDate is "+ppd.getDueDate();
	
	
}
}

