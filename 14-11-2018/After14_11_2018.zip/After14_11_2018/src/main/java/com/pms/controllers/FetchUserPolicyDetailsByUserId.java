package com.pms.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.pms.Entities.PolicyReturnObject;
import com.pms.Entities.PolicyTable;
import com.pms.Entities.UserEnrolledPolicy;
import com.pms.service.Service1;

@RestController
@CrossOrigin
public class FetchUserPolicyDetailsByUserId {
	@Autowired
	Service1 simple;
	List<String> policyIds=null;
	List<PolicyReturnObject> ptl=null;
	@GetMapping("/we/")
	public ResponseEntity<?> FetchUserPolicyDetails(@RequestParam("userid") String Userid){
		 ptl=new ArrayList();
		System.out.println(" FetchUserPolicyDetails in for " + Userid );
		List<UserEnrolledPolicy> ueps=simple.findByUserId(Userid);
		if(ueps.isEmpty())
		{
		String msg="User not registered with any policy";
		return new ResponseEntity<List<PolicyReturnObject>> (ptl,HttpStatus.OK);
		}
		else {	
		PolicyTable pt=null ;
		PolicyReturnObject pro = new PolicyReturnObject();;
		//List<PolicyTable> lstpt=new ArrayList();
	
		policyIds=new ArrayList<>();
		System.out.println(ueps.size());
		for(int i=0;i<ueps.size();i++)
		{
			
			
			policyIds.add(i, ueps.get(i).getPolicy().getPolicyId());
			
			System.out.println(policyIds.get(i));
			//pt.add(simple.findById(policyIds.get(i)));
			pt=simple.findById(policyIds.get(i));
			System.out.println(pt.getCompany().getCompanyName());
			pro.setCompanyName(pt.getCompany().getCompanyName());
			pro.setPolicyName(pt.getPolicyName());
			pro.setTermAmount(pt.getTermAmount());
			/*//
		String companyNanme= compdao.findByCompanyName();
		*/
	    ptl.add(i,pro);

		System.out.println("FetchUserPolicyDetails out");
		
		
			
		}
		
    return new ResponseEntity<List<PolicyReturnObject>> (ptl,HttpStatus.OK);
	//	return null;
}
		
	}
}
