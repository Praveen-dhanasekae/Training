import { Component, OnInit,Output,EventEmitter } from '@angular/core';
import { searchPolicy } from '../interfaces';
import { SearchingService } from '../searching.service';
@Component({
  selector: 'app-user-interface',
  templateUrl: './user-interface.component.html',
  styleUrls: ['./user-interface.component.css'],
  providers:[SearchingService]
})
export class UserInterfaceComponent implements OnInit {
  duration:String;
  companyName:String;
  policyType:String;
  PID:String;
  policyName:String;
  object1:string[];
  
  constructor(private services: SearchingService) { }
   

  @Output()
  out = new EventEmitter();
  SearchPolicy(){
    


    const searchPoli : searchPolicy={
      duration:this.duration,
      company:{"companyId":this.companyName},
      policyType:this.policyType,
    
      policyName:this.policyName
    }
  
 this.services.searching(searchPoli).subscribe((response)=>{
   this.object1 = response as string[];
   this.out.emit(this.object1);
   console.log(this.object1);
 });


  }

  ngOnInit() {
  }

}
