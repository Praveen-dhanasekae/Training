import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {UserdashService} from '../userdash.service';
@Component({
  selector: 'app-user-dashboard',
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.css'],
  providers:[UserdashService]
})
export class UserDashboardComponent implements OnInit {
  userIds:string;
  obj:any=[];
  loadChild = false;
  constructor(private route:ActivatedRoute,private services:UserdashService,private router:Router) { }
  search:any=[];
  polID:any;
  ngOnInit() {
    this.obj = [];
   this.userIds = this.route.snapshot.paramMap.get('userId');
   console.log(this.userIds);
   this.services.sendParams(this.userIds).subscribe((response) =>{
     this.obj = response;
     console.log(this.obj);
   });
   
  }

  call(){
     this.loadChild = true;
  }

  objs($event){
   this.search = $event;
   this.polID = this.search[0].policyId; 
  //  console.log($event);
  //  console.log(this.search[0].policyId);
  }

   funcall(){
     console.log(this.polID);
     this.router.navigate(['Conform',{ policyIds:this.polID,
      userid:this.userIds}]);
   }


}
