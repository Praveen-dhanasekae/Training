import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PolicymappingService {

  constructor(private https:HttpClient) { }
  policyRegistering(obj:any){
   return this.https.post("http://10.230.174.247:1214/registeringPolicy/",obj,{responseType:'text' as 'text'});
  }
}
