import { Component, OnInit } from '@angular/core';
import { editPolicy } from '../interfaces';
import { EditService } from '../edit.service';
@Component({
  selector: 'app-edit-policy',
  templateUrl: './edit-policy.component.html',
  styleUrls: ['./edit-policy.component.css'],
  providers:[EditService]
})
export class EditPolicyComponent implements OnInit {
  policyName:string;
  duration:string;
  startDate:string;
  policyType:string;
  termAmount:string;
  edit:string;
  constructor(private services:EditService) { }

  EditPolicy(){
    const editPoll : editPolicy = {
      policyName:this.policyName,
      duration:this.duration,
      startDate:this.startDate,
      policyType:this.policyType,
      termAmount:this.termAmount
    }
    this.services.Editpolicy(editPoll).subscribe((response)=>{
      this.edit = response;
      console.log(this.edit);
    })

    
  }
  ngOnInit() {
  }

}
