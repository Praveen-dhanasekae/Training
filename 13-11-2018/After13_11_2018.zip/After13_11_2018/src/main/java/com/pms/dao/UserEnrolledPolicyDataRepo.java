package com.pms.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.pms.Entities.UserEnrolledPolicy;
@Repository
public interface UserEnrolledPolicyDataRepo  extends JpaRepository<UserEnrolledPolicy, Integer> {
	@Query("select uep from UserEnrolledPolicy uep where uep.user.userid= :userid")
    public List<UserEnrolledPolicy> findByUserId(@Param ("userid") String userid);

}
