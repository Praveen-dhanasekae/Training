package com.pms.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.pms.Entities.PolicyTable;

@Repository
public interface PolicyDataRepo  extends JpaRepository<PolicyTable, String>  {

  
    //public List<Mainuser> findByIdEquals(String a);
    
   // @Query("select pt from PolicyTable pt where pt.policyType = :policy order by pt.policyId DESC limit 1 ")
    public List<PolicyTable> findByPolicyTypeOrderByPolicyIdDesc(@Param ("policy") String userid);
    
    @Query("select count(uep.policy.policyId) from UserEnrolledPolicy uep where uep.user.userid= :userid and uep.policy.policyId like %:var% ")
    public int findNumber(@Param ("userid") String userid, @Param("var") String var);
/*    @Query("select uep from UserEnrolledPolicy uep where uep.user.userid= :userid")
    public List<UserEnrolledPolicy> findByUserId(@Param ("userid") String userid);
//findByPolicyTypeOrderByPolicyTypeDesc	
*/    //started from here 
    @Query("select pt from PolicyTable pt where pt.policyType =policyType and pt.policyName=policyName order by pt.policyId")
	 public List<PolicyTable> findByPolicyTypeandName(@Param ("policyType") String policyType,@Param ("policyName") String policyName);

    @Query("select p from  PolicyTable p where p.company.companyId= :companyName or p.duration= :years or p.policyName= :policyName or p.policyType = :policyType ")
    public List<PolicyTable> searchPolicy(@Param ("companyName") String companyName,@Param ("years") int years,@Param ("policyType") String policyType, @Param ("policyName") String policyName);

	public PolicyTable findByPolicyId(String policyId);
    
    
}