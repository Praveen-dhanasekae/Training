import { Component, OnInit } from '@angular/core';
import { userRegister } from '../interfaces';
import swal from 'sweetalert';
import {Router} from '@angular/router';
import {UserSignInPageComponent } from '../user-sign-in-page/user-sign-in-page.component';
import { UserRegisterService} from '../user-register.service';
@Component({
  selector: 'app-user-register',
  templateUrl: './user-register.component.html',
  styleUrls: ['./user-register.component.css']
})
export class UserRegisterComponent implements OnInit {

  constructor(private route:Router,private service:UserRegisterService) { }

  firstName: string;
  lastName: string;
  dob: string;
  address: string;
  contactNo: string;
  emailId: string;
  qualification: string;
  salary: string;
  panNo: string;
  employerType: string;
  gender:string;
  Question: string;
  str:string;
  hintans: string;
  employer: string;
  hintId:number;

  Validation() {
       
      if(this.Question === "What is your Fathers Name?"){
         this.hintId = 1;
      }else if(this.Question === "What is your Pets Name?"){
         this.hintId = 2;
      }else if(this.Question === "What is your Mothers Name?"){
        this.hintId = 3;
     }else if(this.Question === "Who is your favourite actor Name?"){
      this.hintId = 4;
   }else if(this.Question === "What is your school name?"){
    this.hintId = 5;
 }
    const userRegis: userRegister = {
      firstName: this.firstName,
      lastName: this.lastName,
      dob: this.dob,
      address: this.address,
      contactNo: this.contactNo,
      emailId: this.emailId,
      qualification: this.qualification,
      salary: this.salary,
      panNo: this.panNo,
      employerType: this.employerType,
      employer: this.employer,
      hint:{"hintid":"3"},
      hintid:this.hintId,
      hintans: this.hintans,
      gender:this.gender

    }
  console.log(this.Question+"==="+this.hintId);
  this.service.storeData(userRegis).subscribe((response)=>{
    this.str = response;
    this.msg(this.str);
console.log(response);
  });
    
 
     // swal( this.str ,"success");
       
      //this.route.navigate(["Signin"]);
  
      //swal("Sorry !", "You are not eligible for registration because of Age Mis Match", "error");
     
    
    //document.forms[0].reset();



  }


msg(message:string){

  if(message.substring(0,3) === "The"){

  swal("success" , this.str ,"success");

  this.route.navigate(['Signin']);
}else{
  swal("error",this.str,"error");
 // document.forms[0].reset();
}


}


  ngOnInit() {


  }


}
