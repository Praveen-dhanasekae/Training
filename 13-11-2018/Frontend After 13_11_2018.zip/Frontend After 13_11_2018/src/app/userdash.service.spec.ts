import { TestBed } from '@angular/core/testing';

import { UserdashService } from './userdash.service';

describe('UserdashService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UserdashService = TestBed.get(UserdashService);
    expect(service).toBeTruthy();
  });
});
