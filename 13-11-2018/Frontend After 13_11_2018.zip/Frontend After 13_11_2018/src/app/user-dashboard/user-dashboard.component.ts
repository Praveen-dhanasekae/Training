import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {UserdashService} from '../userdash.service';
@Component({
  selector: 'app-user-dashboard',
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.css'],
  providers:[UserdashService]
})
export class UserDashboardComponent implements OnInit {
  userIds:string;
  obj:any=[];

  constructor(private route:ActivatedRoute,private services:UserdashService) { }

  ngOnInit() {
    this.obj = [];
   this.userIds = this.route.snapshot.paramMap.get('userId');
   console.log(this.userIds);
   this.services.sendParams(this.userIds).subscribe((response) =>{
     this.obj = response;
     console.log(this.obj);
   });
   
  }




}
