import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SearchingService {

  constructor(private http: HttpClient) { }

  searching(object1):Observable<any[]>{
    //let val = new HttpParams().set("gowtham",object1)
    console.log(object1);
    return this.http.post<any[]>("http://10.230.174.247:1214/searchingPolicy/",object1);
  }
}
