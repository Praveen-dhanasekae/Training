
package com.PMSProjectService;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.PMSProjectDao.PaymentAcessDao;
import com.PMSProjectDao.PolicyAcessDao;
import com.PMSProjectDao.UserAcessDao;
import com.PMSProjectModel.Mainuser;
import com.PMSProjectModel.Payment;
import com.PMSProjectModel.PaymentObject;
import com.PMSProjectModel.PaymentSucess;
import com.PMSProjectModel.Policy_Table;
import com.PMSProjectModel.PolicyPaymentDisplay;
import com.PMSProjectModel.Policyterminfo;
import com.PMSProjectModel.Mainuser;

@Service
public class PaymentService implements PaymentServiceInterface {
@Autowired
PaymentAcessDao  pad;
@Autowired
PolicyAcessDao policyacess;
Payment payment = new Payment();;
@Autowired
PolicyPaymentDisplay pd;
Policy_Table pinfo;
LocalDate ld ;
String  policyName=null;
@Autowired
PaymentSucess ps;
Mainuser u;
@Autowired
UserAcessDao uad;
@Override
public PolicyPaymentDisplay generateBill(PaymentObject obj) {

    payment= pad.findByName(obj.getUser(),obj.getPolicy());
   /* System.out.println(payment.getBill_Id());
    System.out.println(payment.getBill_Date());
    System.out.println(payment.getDue_Date());
    System.out.println(payment.getFine());
    System.out.println(payment.getUser());*/
    
    policyName=policyacess.findByPolicyname(obj.getPolicy());
    System.out.println(policyName);
    pd.setPolicyId(obj.getPolicy());
    pd.setPolicyName(policyName);
    ld =java.time.LocalDate.now(); 
    pd.setCurrentDate(ld);
    pd.setUserId(obj.getUser());
    pinfo=policyacess.findPolicyTerm(obj.getPolicy());
    System.out.println(pinfo.getTerm_Amount());
    if(payment==null) {
    	pd.setFine(0);
    	System.out.println(pinfo.getTerm_Amount());
    	pd.setAmount(pinfo.getIntial_Deposit()+pinfo.getTerm_Amount());
    	pd.setDueDate(ld.plusMonths((long)pinfo.getTerms_Per_Year()));
    	return pd;
    }  
    
    else {
    	
    	
    	if(ld.isBefore(payment.getDue_Date())||(ld.compareTo(payment.getDue_Date())==0)) {
    		pd.setFine(0);
    		pd.setAmount(pinfo.getTerm_Amount());
    		pd.setDueDate(payment.getDue_Date().plusMonths((long)pinfo.getTerms_Per_Year()));
    		
    	}
    	else {
    		System.out.println("Hello Maven");
    		LocalDate d1 = payment.getDue_Date();
    		LocalDate d2=d1;
    		while(d1.isBefore(ld)) {
    			d1=d1.plusMonths((long)pinfo.getTerms_Per_Year());
    		}
    		long daysBetween = java.time.temporal.ChronoUnit.DAYS.between(ld, d2);
    		System.out.println(daysBetween);
    		String polId=obj.getPolicy();
    		String[] a = polId.split("-",-2);
    		System.out.println(a[1]);
    		double finepercent=0;
    		 switch(a[1]) {
    		 case "VL":finepercent=5;
    		 			break;
    		 case "TI":finepercent=4.5;
    		 			break;
    		 case "LI":finepercent=4;
    		 			break;
    		 case "HI":finepercent=4;
    		 			break;
    		 case "CP":finepercent=4.75;
	 			break;
    		 case "RP":finepercent=2.5;
	 			break;
    		 
    		 }
    		 System.out.println(finepercent);
    		
    		 
    		double fine = (finepercent*pinfo.getTerm_Amount())/100;
    		double amtToPay=fine*Math.abs(daysBetween)+pinfo.getTerm_Amount();
    		pd.setAmount(amtToPay);
    		pd.setFine(fine);
    		pd.setDueDate(d1);
    		
    	}
    	return pd;
    }
    
}
public String sucessMsg(PolicyPaymentDisplay ppd) {
	 
	ps.setDuedate(ppd.getDueDate());
	System.out.println(ps.getDuedate());
	String billId=pad.findLatestBill();
	String a[]= billId.split("-",-3);
	
	int p =Integer.parseInt(a[a.length-1]);
	p=p+1;
	String wfof=null;
	if(ppd.getFine()==0)
	{
		wfof="ON";
	}
	else
		wfof="WF";
	billId=ppd.getPolicyId()+"-"+wfof+"-"+String.format("%03d", p);
	
	
	ps.setBillId(billId);
	System.out.println(billId);
	
	Mainuser user=uad.findByUserid(ppd.getUserId());
	System.out.println(user.getFirstName());
	
	//pad.insertNewBill(ppd.getCurrentDate(),ps.getBillId(),ppd.getDueDate(),ppd.getFine(),ppd.getAmount(),user);
	if(payment==null) {
		payment=new Payment();
	}
	payment.setBill_Id(billId);
	payment.setBill_Date(ppd.getCurrentDate());
	payment.setDue_Date(ppd.getDueDate());
	payment.setFine(ppd.getFine());
	payment.setPaid_Amt(ppd.getAmount());
	payment.setUser(user);
	pad.save(payment);
	return "Payment Sucessfull.Your Bill Id is "+billId+"Next DueDate is "+ppd.getDueDate();
	
	
}
}

