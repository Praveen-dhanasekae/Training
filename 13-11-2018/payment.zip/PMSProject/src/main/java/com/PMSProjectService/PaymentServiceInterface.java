package com.PMSProjectService;

import com.PMSProjectModel.Payment;
import com.PMSProjectModel.PaymentObject;
import com.PMSProjectModel.PolicyPaymentDisplay;

public interface PaymentServiceInterface {

	PolicyPaymentDisplay generateBill(PaymentObject obj);

}