package com.PMSProjectController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.PMSProjectModel.Payment;
import com.PMSProjectModel.PaymentObject;
import com.PMSProjectModel.PaymentSucess;
import com.PMSProjectModel.PolicyPaymentDisplay;
import com.PMSProjectService.PaymentService;

@RestController
@CrossOrigin
public class PaymentController {

	@Autowired
	PaymentService paymentservice;
	PolicyPaymentDisplay pm=null;
	String ps=null;
	@PostMapping(value="/paymentBill/")
	public PolicyPaymentDisplay PolicyPayment(@RequestBody PaymentObject pob) {
        // @RequestBody LoginObject value   2. value
		System.out.println("Hi i am generating bill");
		 pm=paymentservice.generateBill(pob);
		System.out.println("controller");     
		return pm;
		//return new ResponseEntity<Map<String,String>>(value , HttpStatus.OK);
	}
	@PostMapping(value="/paymentSucess/")
	public String Finalpayment(@RequestBody PolicyPaymentDisplay ppd) {
        // @RequestBody LoginObject value   2. value
		System.out.println("Hi i am generating bill");
		 ps=paymentservice.sucessMsg(ppd);
		System.out.println("controller");     
		return ps;
		//return new ResponseEntity<Map<String,String>>(value , HttpStatus.OK);
	}

}
