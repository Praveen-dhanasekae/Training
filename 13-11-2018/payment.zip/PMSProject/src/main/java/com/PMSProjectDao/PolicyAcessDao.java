package com.PMSProjectDao;


import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Example;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.PMSProjectModel.Policy_Table;
import com.PMSProjectModel.Policy_Table;
import com.PMSProjectModel.Policyterminfo;


@Repository
public interface PolicyAcessDao extends JpaRepository<Policy_Table,String>  {

@Query(value="select * from policy_table p where p.policy_id=:policy",nativeQuery=true)
Policy_Table findPolicyTerm(String policy);
@Query(value="select p.policy_name from Policy_Table p where p.policy_id=:policy",nativeQuery=true)
String findByPolicyname(String policy);
}

