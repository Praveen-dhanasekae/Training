package com.PMSProjectDao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.PMSProjectModel.Mainuser;


@Repository
public interface UserAcessDao extends JpaRepository<Mainuser,String> {

     @Query(value="select * from mainuser m where m.user_id=:userid",nativeQuery=true)
	 public Mainuser findByUserid(String userid);
}
