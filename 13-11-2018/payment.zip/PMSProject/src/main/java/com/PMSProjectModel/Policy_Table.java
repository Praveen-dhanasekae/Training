package com.PMSProjectModel;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="policy_table")
public class Policy_Table {
	@Id
	private String policy_id;
	@Column(name="policy_name")
	private String policy_name;
	@Column(name="policy_type")
	private String policy_type;
	@Column(name="start_date")
	private LocalDate Start_Date;
	@Column(name="duration")
	private int Duration;
	@Column(name="initial_deposit")
	private double initial_deposit;
	@Column(name="terms_per_year")
	private int terms_per_year;
	@Column(name="term_amount")
	private int term_amount;
	@Column(name="interest")
	private double interest;
	@ManyToOne
	private Company company;
	@OneToMany(mappedBy="policy")
	private List<User_Enrolled_Policy> peu =new ArrayList<>();
	@ManyToOne
	private Usertype userType;
	
	public Usertype getUserType() {
		return userType;
	}
	public void setUserType(Usertype userType) {
		this.userType = userType;
	}
	public List<User_Enrolled_Policy> getPeu() {
		return peu;
	}
	public void setPeu(List<User_Enrolled_Policy> peu) {
		this.peu = peu;
	}
	public Company getCompany() {
		return company;
	}
	public void setCompany(Company company) {
		this.company = company;
	}
	public String getPolicy_id() {
		return policy_id;
	}
	public void setPolicy_id(String policy_id) {
		this.policy_id = policy_id;
	}
	public String getPolicy_Name() {
		return policy_name;
	}
	public void setPolicy_Name(String policy_Name) {
		policy_name = policy_Name;
	}
	public String getPolicy_type() {
		return policy_type;
	}
	public void setPolicy_type(String policy_type) {
		this.policy_type = policy_type;
	}
	public LocalDate getStart_Date() {
		return Start_Date;
	}
	public void setStart_Date(LocalDate start_Date) {
		Start_Date = start_Date;
	}
	public int getDuration() {
		return Duration;
	}
	public void setDuration(int duration) {
		Duration = duration;
	}
	public double getIntial_Deposit() {
		return initial_deposit;
	}
	public void setIntial_Deposit(double intial_Deposit) {
		initial_deposit = intial_Deposit;
	}
	public int getTerms_Per_Year() {
		return terms_per_year;
	}
	public void setTerms_Per_Year(int terms_Per_Year) {
		terms_Per_Year = terms_Per_Year;
	}
	public int getTerm_Amount() {
		return term_amount;
	}
	public void setTerm_Amount(int term_Amount) {
		term_amount = term_Amount;
	}
	public double getInterest() {
		return interest;
	}
	public void setInterest(double interest) {
		interest = interest;
	}
	
}
	
	
