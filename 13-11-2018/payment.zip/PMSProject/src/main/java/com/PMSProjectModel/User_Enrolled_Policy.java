
package com.PMSProjectModel;


import java.time.LocalDate;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.ManyToOne;
@Entity
public class User_Enrolled_Policy {
	
	@javax.persistence.Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int Id;
	@ManyToOne
	Mainuser user;
	@ManyToOne
	Policy_Table policy;
	@Column(name="enrolled_date")
	private LocalDate EnrolledDate;
	public Mainuser getUser() {
		return user;
	}
	public void setUser(Mainuser user) {
		this.user = user;
	}
	public Policy_Table getPolicy() {
		return policy;
	}
	public void setPolicy(Policy_Table policy) {
		this.policy = policy;
	}
	
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	
	public LocalDate getEnrolledDate() {
		return  EnrolledDate;
	}
	public void setEnrolledDate(LocalDate enrolledDate) {
		EnrolledDate = enrolledDate;
	}
	
	
	

}
