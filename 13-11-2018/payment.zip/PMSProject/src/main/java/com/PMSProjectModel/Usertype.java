package com.PMSProjectModel;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Usertype {
@Id
 private int typeid;
@Column
private String type_variable;
@OneToMany(mappedBy="userType")
 private List<Policy_Table> policies = new ArrayList<>();
public int getUsertypeid() {
	return typeid;
}
public void setUsertypeid(int usertypeid) {
	typeid = usertypeid;
}
public String getUsertypevariable() {
	return type_variable;
}
public void setUsertypevariable(String usertypevariable) {
	type_variable = usertypevariable;
}
public List<Policy_Table> getPolicies() {
	return policies;
}
public void setPolicies(List<Policy_Table> policies) {
	this.policies = policies;
}

}
