package com.PMSProjectModel;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="Company")
public class Company {
@Id
@Column(name="company_id")
private String company_id;
@Column(name="company_name")
private String company_name;
@OneToMany(mappedBy="company")
List<Policy_Table> policies = new ArrayList<>();public List<Policy_Table> getPolicies() {
	return policies;
}
public void setPolicies(List<Policy_Table> policies) {
	this.policies = policies;
}
public String getCompany_Id() {
	return company_id;
}
public void setCompany_Id(String company_Id) {
	company_id = company_Id;
}
public String getCompany_Name() {
	return company_name;
}
public void setCompany_Name(String company_Name) {
	company_Name = company_Name;
}

}
