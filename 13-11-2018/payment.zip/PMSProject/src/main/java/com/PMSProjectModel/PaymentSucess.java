package com.PMSProjectModel;

import java.time.LocalDate;

import org.springframework.stereotype.Component;

@Component
public class PaymentSucess {
	
	private String BillId;
	private LocalDate Duedate;
	public String getBillId() {
		return BillId;
	}
	public void setBillId(String billId) {
		BillId = billId;
	}
	public LocalDate getDuedate() {
		return Duedate;
	}
	public void setDuedate(LocalDate duedate) {
		Duedate = duedate;
	}
	

}
