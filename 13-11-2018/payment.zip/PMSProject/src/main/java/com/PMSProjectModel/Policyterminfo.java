package com.PMSProjectModel;

import org.springframework.stereotype.Component;

@Component
public class Policyterminfo {
	private int termsperyear;
	private int termamount;

	public int getTermsperyear() {
		return termsperyear;
	}
	public void setTermsperyear(int termsperyear) {
		this.termsperyear = termsperyear;
	}
	public int getTermamount() {
		return termamount;
	}
	public void setTermamount(int termamount) {
		this.termamount = termamount;
	}
	
}
