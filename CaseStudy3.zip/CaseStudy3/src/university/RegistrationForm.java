package university;

public class RegistrationForm {
	private String name,martialStatus,sex,address,primaryEmailId,secondaryEmailId;
	private String highestEducationQualifiaction,nationality,emailId,interestedSubject;
	public RegistrationForm(String name, String martialStatus, String sex, String address, String primaryEmailId,
			String secondaryEmailId, String highestEducationQualifiaction, String nationality, String emailId, String interestedSubject) {
		super();
		this.name = name;
		this.martialStatus = martialStatus;
		this.sex = sex;
		this.address = address;
		this.primaryEmailId = primaryEmailId;
		this.secondaryEmailId = secondaryEmailId;
		this.highestEducationQualifiaction = highestEducationQualifiaction;
		this.nationality = nationality;
		this.emailId = emailId;
		this.interestedSubject=interestedSubject;
	}
	
	
	
}
