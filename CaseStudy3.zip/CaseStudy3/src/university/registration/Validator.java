package university.registration;
import university.Student;
import university.exceptions.AgeException;
import university.exceptions.ValidatorException;

public class Validator {
	private static Validator validator;
	private Validator(){
	}
	public static Validator getValidator(){
		if(validator==null)
			validator=new Validator();
		return validator;
	}

	public boolean validatorStudentDetails(Student student) throws ValidatorException{

		
			int age=Integer.parseInt(student.getAge());
			if((age>35)||(age<23))
				throw new AgeException("Age is not within limits......");

		if((!(student.getName().equals(null)))&&(!(student.getEmailId().equals(null)))&&((student.getNationality().equalsIgnoreCase("indian"))))
			return true;
		else return false;
	}


}