package university.exceptions;

public class ValidatorException extends RegistrationException{
	
	public ValidatorException(String s) {
		
		super(s);        
	}

} 
