package university.exceptions;

public class AgeException extends ValidatorException {

	public AgeException(String s) {
		super(s);
		
	}

}
