package university.exceptions;

public class UniversityException extends Exception {

	   public UniversityException(String s) {
		   super(s);
	   }
}
