package university.exceptions;

public class RegistrationException extends  UniversityException{

	public RegistrationException(String s) {
      super(s);	
	}

}
