package university.examination;

public class Exam {
	Paper paper;
	public Exam(Paper paper1){
		paper=paper1;
	}
	
  public Paper getPaper(){
	  
	  return paper;
  }

}
