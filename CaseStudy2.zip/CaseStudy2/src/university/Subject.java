package university;

public class Subject {
	
	Subject(){
		
	}
	

}

class Maths extends Subject{
	
	
	
}


class Science extends Subject{
	
}

class Social extends Subject{
	
}