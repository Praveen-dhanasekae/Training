package university.examination;

public class Evaluator {
	private static Evaluator evaluator;
	private Evaluator(){
	}
	public static Evaluator  getEvaluator(){
		if(evaluator==null)
			evaluator=new Evaluator();
		return evaluator;
	}
	
    String evaluate(Paper paper){
    	
    	String result="pass";
    	return result;
    }
}
