package university.registration;
import university.Student;

public class Registrar {
	static long admissionId=001;;
	private static Registrar registrar;
	private Registrar(){
	}
	public static Registrar getRegistrar(){
		if(registrar==null)
			registrar=new Registrar();
		return registrar;
	}
	
	public String registerStudent(Student student){
		boolean boo;
		Validator dummy=Validator.getValidator();
		boo= dummy.validatorStudentDetails(student);
		if(boo==true) 
		  return ""+(admissionId++)+"";
		else  return "0";
	}
	

}
