package university.registration;
import university.Student;

public class Validator {
	private static Validator validator;
	private Validator(){
	}
	public static Validator getValidator(){
		if(validator==null)
			validator=new Validator();
		return validator;
	}
	
	public boolean validatorStudentDetails(Student student){
		
		if((!(student.getName().equals(null)))&&(!(student.getEmailId().equals(null)))&&((student.getNationality().equalsIgnoreCase("indian"))))
		 return true;
		else return false;
	}
	

}