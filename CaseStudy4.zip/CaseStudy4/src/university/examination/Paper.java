package university.examination;

public class Paper  {
	String paperName="TestPaper";
	//Subject sub=new Subject();
	
	public String submit(){
		Evaluator evaluate=Evaluator.getEvaluator();
		String result=evaluate.evaluate(this);
		return result;
	}
    
	
}
