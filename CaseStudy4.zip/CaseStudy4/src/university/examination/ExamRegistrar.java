package university.examination;
import university.Student;

public class ExamRegistrar {
	private static ExamRegistrar examRegistrar;
	private ExamRegistrar(){
	}
	public static ExamRegistrar getExamRegistrar(){
		if(examRegistrar==null)
			examRegistrar=new ExamRegistrar();
		return examRegistrar;
	}
	
	public Exam registeringStudentForExamination(Student student){
		
		Paper paper1=new Paper();
	    Exam a=new Exam(paper1);
	    return a;
	}
	

}