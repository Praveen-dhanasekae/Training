package university.registration;
import university.Student;
import university.exceptions.AgeException;
import university.exceptions.ValidatorException;

public class Validator extends Thread {
	Student[] stud=new Student[5];static int threadvalue=1; 
	static int count=30;
	Thread validator1=new Thread("valid1");
	Thread validator2=new Thread("valid2");
	Thread validator3=new Thread("valid3");
	Thread validator4=new Thread("valid4");
	Thread validator5=new Thread("valid5");
	private ThreadLocal<String> resultValidation=new ThreadLocal<>();
	public void run(){
		try {
		if(Thread.currentThread().getName().equals("valid1")) validate(stud[0]); 
		else if(Thread.currentThread().getName().equals("valid2")) validate(stud[1]); 
		else if(Thread.currentThread().getName().equals("valid3")) validate(stud[2]); 
		else if(Thread.currentThread().getName().equals("valid4")) validate(stud[3]); 
		else if(Thread.currentThread().getName().equals("valid5")) validate(stud[4]); 
		
	}
		catch(Exception ex) { System.out.println("Validators confused");
		ex.printStackTrace();		
			
		}
	}
	
	public synchronized void validate(Student stud) throws AgeException, InterruptedException {
		int age=Integer.parseInt(stud.getAge());
		if((age>35)||(age<23))
			throw new AgeException("Age is not within limits......");

	if((!(stud.getName().equals(null)))&&(!(stud.getEmailId().equals(null)))&&((stud.getNationality().equalsIgnoreCase("indian"))))
		{ count--;resultValidation.set("true");}
	else resultValidation.set("false");
		
	}
	private static Validator validator;
	private Validator(){
		for(int i=0;i<5;i++)
			stud[i]=new Student();
		
	}
	public static Validator getValidator(){
		if(validator==null)
			validator=new Validator();
		return validator;
	}

	public Boolean validatorStudentDetails(Student student) throws ValidatorException{

		if(threadvalue==1)
		{   stud[0]=student;
			if(!validator1.isAlive()) validator1.start();
			threadvalue++;
			return Boolean.getBoolean(resultValidation.get());
		}
		else if(threadvalue==2) {
			stud[1]=student;
			if(!validator2.isAlive()) validator2.start();
			threadvalue++;
			return Boolean.getBoolean(resultValidation.get());
			
		}
		else if(threadvalue==3) {
			stud[2]=student;
			if(!validator3.isAlive()) validator3.start();
			threadvalue++;
			return Boolean.getBoolean(resultValidation.get());
			
		}
		else if(threadvalue==4) {
			stud[3]=student;
			if(!validator4.isAlive()) validator4.start();
			threadvalue++;
			return Boolean.getBoolean(resultValidation.get());
			
		}
		else {
			stud[4]=student;
			if(!validator5.isAlive()) validator5.start();
			threadvalue = 1;
			return Boolean.getBoolean(resultValidation.get());
		}
			
	}


}