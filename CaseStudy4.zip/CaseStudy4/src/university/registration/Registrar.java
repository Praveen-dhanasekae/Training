package university.registration;
import university.Student;
import university.exceptions.RegistrationException;

public class Registrar extends Thread{
	static int count=30;
	static long admissionId=001;;
	private static Registrar registrar;
	Student[] stud=new Student[5];static int threadvalue=1; 
	
	Thread registrar1=new Thread("register1");
	Thread registrar2=new Thread("register2");
	Thread registrar3=new Thread("register3");
	Thread registrar4=new Thread("register4");
	Thread registrar5=new Thread("register5");
	private ThreadLocal<Boolean> resultValidation=new ThreadLocal<>();
	private ThreadLocal<String> admId=new ThreadLocal<>();
	public void run(){
		try {
		if(Thread.currentThread().getName().equals("register1")) registerStudent(stud[0]); 
		else if(Thread.currentThread().getName().equals("register2")) registerStudent(stud[1]); 
		else if(Thread.currentThread().getName().equals("register3")) registerStudent(stud[2]); 
		else if(Thread.currentThread().getName().equals("register4")) registerStudent(stud[3]); 
		else if(Thread.currentThread().getName().equals("register5")) registerStudent(stud[4]); 
		
	}
		catch(Exception ex) { System.out.println("Validators confused");
		ex.printStackTrace();		
			
		}
	}
	private Registrar(){
		for(int i=0;i<5;i++)
			stud[i]=new Student();
	}
	public static Registrar getRegistrar(){
		if(registrar==null)
			registrar=new Registrar();
		return registrar;
	}
	
	public synchronized void regStudent(Student student) throws RegistrationException {
		boolean boo=false;
		Validator dummy=Validator.getValidator();
			resultValidation.set(dummy.validatorStudentDetails(student));
		if((boo==true)&&(count>0)) {
			count--;
			admId.set(""+(admissionId++)+"");	
		}
		else  {throw new RegistrationException("Maximum seats allocated...Regsitrations has closed");}
		
		
	}
	
	public String registerStudent(Student student) throws RegistrationException{
		if(threadvalue==1)
		{   stud[0]=student;
			if(!registrar1.isAlive()) registrar1.start();
			threadvalue++;
			return admId.get();
		}
		else if(threadvalue==2) {
			stud[1]=student;
			if(!registrar2.isAlive()) registrar2.start();
			threadvalue++;
			return admId.get();			
		}
		else if(threadvalue==3) {
			stud[2]=student;
			if(!registrar1.isAlive()) registrar3.start();
			threadvalue++;
			return admId.get();			
		}
		else if(threadvalue==4) {
			stud[3]=student;
			if(!registrar1.isAlive()) registrar4.start();
			threadvalue++;
			return admId.get();			
		}
		else {
			stud[4]=student;
			if(!registrar1.isAlive()) registrar5.start();
			threadvalue = 1;
			return admId.get();		}
		
	}
	

}
