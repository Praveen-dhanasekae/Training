package university;
import university.examination.Exam;
import university.examination.ExamRegistrar;
import university.exceptions.UniversityException;
import university.registration.Registrar;

public class Student {
	private String name,age,martialStatus,sex,address,primaryEmailId,secondaryEmailId;
	private String highestEducationQualifiaction,nationality,emailId;
	private String admissionId,result;
	Exam exam;
	Registrar registrar ;
	Subject sub;
	RegistrationForm register;
	public Student() {

	}

	public Student(String name, String martialStatus, String sex, String address, String primaryEmailId,
			String secondaryEmailId, String highestEducationQualifiaction, String nationality, String emailId,
			String admissionId) {
		this.name = name;
		this.martialStatus = martialStatus;
		this.sex = sex;
		this.address = address;
		this.primaryEmailId = primaryEmailId;
		this.secondaryEmailId = secondaryEmailId;
		this.highestEducationQualifiaction = highestEducationQualifiaction;
		this.nationality = nationality;
		this.emailId = emailId;
		this.admissionId = admissionId;
		
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMartialStatus() {
		return martialStatus;
	}

	public void setMartialStatus(String martialStatus) {
		this.martialStatus = martialStatus;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPrimaryEmailId() {
		return primaryEmailId;
	}

	public void setPrimaryEmailId(String primaryEmailId) {
		this.primaryEmailId = primaryEmailId;
	}

	public String getSecondaryEmailId() {
		return secondaryEmailId;
	}

	public void setSecondaryEmailId(String secondaryEmailId) {
		this.secondaryEmailId = secondaryEmailId;
	}

	public String getHighestEducationQualifiaction() {
		return highestEducationQualifiaction;
	}

	public void setHighestEducationQualifiaction(String highestEducationQualifiaction) {
		this.highestEducationQualifiaction = highestEducationQualifiaction;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getAdmissionId() {
		return admissionId;
	}

	public void setAdmissionId(String admissionId) {
		this.admissionId = admissionId;
	}

	public String getResult() {
		return result;
	}

	public Exam getExam() {
		return exam;
	}

	public void setExam(Exam exam) {
		this.exam = exam;
	}

	public void registerStudent() throws UniversityException{
		Registrar dummy=Registrar.getRegistrar();
		admissionId=dummy.registerStudent(this);

	}

	public void registerForExam(){

		ExamRegistrar examregistrar=ExamRegistrar.getExamRegistrar();
		exam=examregistrar.registeringStudentForExamination(this);

	}

	public void appearForExam(){

		System.out.println("Appearing for Exam");
				System.out.println("Submitting paper");
				System.out.println("--------------------------------");
				if(exam.getPaper().submit().equals("pass")){
					System.out.println("Paper Submitted");
					System.out.println("Evaluating...");
					System.out.println("Result : pass");
					System.out.println("--------------------------------");
					result="pass";
				}

	}

    public void subRegister(int i){
    	
    	switch(i) {
    	case 1: sub=new Maths();System.out.println("You have selected Maths as specialization");break;
    	case 2: sub=new Science();System.out.println("You have selected Science as specialization");break;
    	case 3: sub=new Social();System.out.println("You have selected Social as specialization");break;
    	default: System.out.println("Choice not available ...Try again...");System.out.println("-------------------------------");break;
    	
    	
    	}
    	register=new RegistrationForm(name,martialStatus,sex,address,primaryEmailId,secondaryEmailId,highestEducationQualifiaction,nationality,emailId,sub.interestedSubject);
    	
    }

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

}
