package university;

public class Subject {
	
	
	public void setInterestedSubject(String interestedSubject) {
		this.interestedSubject = interestedSubject;
	}
	protected String interestedSubject;
	Subject(){
		
	}
	

}

class Maths extends Subject{
	
	public void setInterestedSubject() {
		this.interestedSubject ="Mathss";
	}
	public String getInterestedSubject() {
		return interestedSubject;
	}
	
	
}


class Science extends Subject{
	public void setInterestedSubject() {
		this.interestedSubject ="Science";
	}
	public String getInterestedSubject() {
		return interestedSubject;
	}
	
}
	

class Social extends Subject{
	public void setInterestedSubject() {
		this.interestedSubject ="Social";
	}
	public String getInterestedSubject() {
		return interestedSubject;
	}
		
}