
public class Exam {
	Paper paper;
	public Exam(Paper paper1){
		paper=paper1;
	}
	
  Paper getPaper(){
	  
	  return paper;
  }

}
