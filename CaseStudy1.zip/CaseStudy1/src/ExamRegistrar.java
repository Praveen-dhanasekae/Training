public class ExamRegistrar {
	private static ExamRegistrar examRegistrar;
	private ExamRegistrar(){
	}
	public static ExamRegistrar examRegistrar(){
		if(examRegistrar==null)
			examRegistrar=new ExamRegistrar();
		return examRegistrar;
	}
	
	public boolean registeringStudentForExamination(Student student){
		
		
		
		
		
		return false;
	}
	

}