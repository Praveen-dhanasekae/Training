
public class Paper {
	String paperName="TestPaper";
	
	String submit(){
		Evaluator evaluate=Evaluator.getEvaluator();
		String result=evaluate.evaluate(this);
		return result;
	}
    
	
}
