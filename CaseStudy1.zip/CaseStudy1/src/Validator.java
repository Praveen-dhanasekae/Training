
public class Validator {
	private static Validator validator;
	private Validator(){
	}
	public static Validator getValidator(){
		if(validator==null)
			validator=new Validator();
		return validator;
	}
	
	public boolean validatorStudentDetails(Student student){
		
		if((!(student.name.equals(null)))&&(!(student.emailId.equals(null)))&&((student.nationality.equalsIgnoreCase("indian"))))
		 return true;
		else return false;
	}
	

}