
public class Student {
	String name,martialStatus,sex,address,primaryEmailId,secondaryEmailId;
	String highestEducationQualifiaction,nationality,emailId;
    String admissionId,result;
    Exam exam;
    Registrar registrar ;
    public void registerStudent(){
    	Registrar dummy=Registrar.getRegistrar();
    	admissionId=dummy.registerStudent(this);
    	
    }
  
    public void registerForExam(){
    	
    }
    
    public void appearForExam(){
    	
    }



}
