
public class Student {
	String name,martialStatus,sex,address,primaryEmailId,secondaryEmailId;
	String highestEducationQualifiaction,nationality,emailId;
    String admissionId,result;
    Exam exam;
    Registrar registrar ;
    public void registerStudent(){
    	Registrar dummy=Registrar.getRegistrar();
    	admissionId=dummy.registerStudent(this);
    	
    }
  
    public void registerForExam(){
    
    	ExamRegistrar examregistrar=ExamRegistrar.getExamRegistrar();
    	exam=examregistrar.registeringStudentForExamination(this);
    	
    }
    
    public void appearForExam(){
    	
    	System.out.println("Appearing for Exam");
    	System.out.println("Submitting paper");
    	System.out.println("--------------------------------");
    	if(exam.paper.submit().equals("pass")){
    		System.out.println("Paper Submitted");
    		System.out.println("Evaluating...");
    		System.out.println("Result : pass");
        	System.out.println("--------------------------------");

    		
    	}
    	
    }



}
