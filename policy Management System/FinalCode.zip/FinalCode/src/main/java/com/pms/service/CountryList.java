package com.pms.service;

import java.util.HashMap;

import org.springframework.stereotype.Component;
@Component
public class CountryList {
	
	HashMap<String,String> CountryCodeList = new HashMap<String,String>();
	CountryList(){
		 String locallist[]= {"Malaysia_MY",	
					"Qatar_QA",	
					"Iceland_IS",	
					"Finland_FI",		
					"Malta_MT",	
					"Switzerland_CH",	
					"Belgium_BE",	
					"Saudi Arabia_SA",
					"Iraq_IQ","Puerto Rico_PR","Chile_CL","Austria_AT","United Kingdom_GB","Panama_PA","Yemen_YE","Macedonia_MK","Canada_CA","Vietnam_VN","Netherlands_NL","United States_US",	
					"China_CN","Honduras_HN","United States_US","Morocco_MA","Indonesia_ID","South Africa_ZA","South Korea_KR","Tunisia_TN","Serbia_RS","Belarus_BY","Taiwan_TW","Sudan_SD",	
					"Bolivia_BO","Algeria_DZ","Argentina_AR","United Arab Emirates_AE","Canada_CA","Lithuania_LT",	
					"Syria_SY",	
					"Russia_RU",	
					"Belgium_BE",	
					"Spain_ES",		
					"Israel_IL",	


					"Denmark_DK",	
					"Costa Rica_CR",	
					"Hong Kong_HK",	
					"Spain_ES",	
					"Thailand_TH",	
					"Ukraine_UA",	
					"Dominican Republic_DO",	
					"Venezuela_VE",	
					"Poland_PL",	
					"Libya_LY",	
					"Jordan_JO",	
					"Hungary_HU",	
					"Guatemala_GT",	
					"Paraguay_PY",	
					"Bulgaria_BG",	
					"Croatia_HR",	
					"Luxembourg_LU",	
					"Singapore_SG",	
					"Ecuador_EC",	
				"Bosnia and Herzegovina_BA",	
				"Nicaragua_NI",	
				"El Salvador_SV",	
				"India_IN",		
				"Greece_GR",	
				"Slovenia_SI",	
				"Italy_IT",	
				"Japan_JP",	
				"Luxembourg_LU",	
				"Switzerland_CH"	,
				"Malta_MT"	,
				"Bahrain_BH",		
				"Montenegro_ME"	,
				"Brazil_BR"	,
				"Norway_NO"	,
				"Switzerland_CH",	
				"Kuwait_KW"	,
				"Egypt_EG"	,
				"Ireland_IE",
				"PeruPE",	
				"Czech Republic_CZ"	,
				"Turkey_TR"	,	
				"Uruguay_UY",
				"Oman_OM",	
				"Serbia and Montenegro_CS",	
				"Albania_AL",	
				"Portugal_PT",	
				"Portugal_LV",	
				"Slovakia_SK",	
				"Mexico_MX",	
				"New Zealand_NZ",	
				"Sweden_SE",		
				"Lebanon_LB",	
				"Germany_DE",	
				"Colombia_CO",	
				"Philippines_PH",	
				"Estonia_EE",	
				"Cyprus_CY",		
				"France_FR"	
	};
		 

	for(String s: locallist) {
		String a[]=s.split("_",-2);
		CountryCodeList.put(a[0], a[a.length-1]);
		System.out.println(CountryCodeList.get(a[0]));
	}
	}
	
	 HashMap<String,String> getCountryList(){
		return CountryCodeList;
	}
	
	
		
}
