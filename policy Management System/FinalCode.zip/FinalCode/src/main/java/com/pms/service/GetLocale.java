package com.pms.service;

import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.ResourceBundle;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Component
public class GetLocale {
	@Autowired
	CountryList countrylist;
	@Autowired
	LocaleList localelist;
	Locale locale;
	
	  String setLocale(Date d,String countryName) {
		
		  HashMap<String,String> hashedcountrylist= countrylist.getCountryList();
			HashMap<String,String> hashedlanguagelist=localelist.getLocaleList();

		 String countryCode=hashedcountrylist.get(countryName);
		 String languageCode= hashedlanguagelist.get(countryCode);
		 locale = new Locale(languageCode,countryCode);
		 System.out.println(locale.getLanguage());
		
		 System.out.println(locale.getCountry());
		 //System.out.print(locale.getDisplayLanguage(locale));
		 //System.out.println(locale.getDisplayCountry());
		
		 //SSystem.out.println(locale);
		
		 ResourceBundle messages = 
		         ResourceBundle.getBundle("MessageBundle",locale);
		 Object[] messageArguments = {
			        d
			      };
		 MessageFormat formatter = new MessageFormat("");
	     formatter.setLocale(locale);

	     formatter.applyPattern(messages.getString("template"));
	     String output = formatter.format(messageArguments);
	     
	     
	     System.out.println(output);
	     
	     //String df= ((SimpleDateFormat) DateFormat.getDateInstance(DateFormat.SHORT,locale)).toPattern();
	    // System.out.println(df);
	     return output;
	     /*DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern(df);
	     
	     LocalDate ld= LocalDate.parse(output,formatter1);
	     System.out.println(ld.format(formatter1));
	     return ld.format(formatter1);*/
		 
	    /* String df= ((SimpleDateFormat) DateFormat.getDateInstance(DateFormat.LONG, Locale.CANADA)).toPattern();
	     System.out.println(df);
	     DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern(df);
	    
	    LocalDate ld= LocalDate.parse(output,formatter1);
	    System.out.println(ld.format(formatter1));
		 
		return null;*/
		
	}
	
}
