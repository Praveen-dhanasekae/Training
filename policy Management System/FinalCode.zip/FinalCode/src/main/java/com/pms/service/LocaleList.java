package com.pms.service;

import java.util.HashMap;

import org.springframework.stereotype.Component;

@Component
public class LocaleList {
	
	 HashMap<String,String> localelist = new HashMap<String,String>();
	 
	 LocaleList(){
		 String locallist[]= {"ms_MY",	
					"ar_QA",	
					"is_IS",	
					"fi_FI",			
					"it_CH",	
					"nl_BE",	
					"ar_SA",
					"ar_IQ","es_PR","es_CL","de_AT","en_GB","es_PA","ar_YE","mk_MK","en_CA","vi_VN","nl_NL","es_US",	
					"zh_CN","es_HN","en_US","ar_MA","in_ID","en_ZA","ko_KR","ar_TN","sr_RS","be_BY","zh_TW","ar_SD",	
					"ja_JP_JP","es_BO","ar_DZ","es_AR","ar_AE","fr_CA","lt_LT",	
					"ar_SY",	
					"ru_RU",	
					"fr_BE",	
					"es_ES",		
					"iw_IL",	


					"da_DK",	
					"es_CR",	
					"zh_HK",		
					"th_TH",	
					"uk_UA",	
					"es_DO",	
					"es_VE",	
					"pl_PL",	
					"ar_LY",	
					"ar_JO",	
					"hu_HU",	
					"es_GT",	
					"es_PY",	
					"bg_BG",	
					"hr_HR",	
					"fr_LU",		
					"es_EC",	
				"sr_BA",	
				"es_NI",	
				"es_SV",	
				"hi_IN",		
				"el_GR",	
				"sl_SI",	
				"it_IT",	
				"ja_JP",	
				"de_LU",	
				"fr_CH"	,
				"mt_MT"	,
				"ar_BH",		
				"sr_ME"	,
					"pt_BR"	,
				"no_NO"	,
					"de_CH",	
				"zh_SG",	
				"ar_KW"	,
				"ar_EG"	,
				"ga_IE"	,
				"es_PE",	
				"cs_CZ"	,
				"tr_TR"	,	
				"es_UY"	,
			    "ar_OM",	
				"sr_CS",	
				"sq_AL",	
				"pt_PT",	
				"lv_LV",	
				"sk_SK",	
				"es_MX",	
				"en_AU",	
				"en_NZ",	
				"sv_SE",		
				"ar_LB",	
				"de_DE",	
				"es_CO",	
				"en_PH",	
				"et_EE",	
				"el_CY",		
				"fr_FR"	
	};
		 

	for(String s: locallist) {
		String a[]=s.split("_",-2);
		localelist.put(a[a.length-1], a[0]);
		
	}
	}
	
	 HashMap<String,String> getLocaleList(){
		return localelist;
	}
	
	
		
}
