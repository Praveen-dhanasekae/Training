package com.pms.dao;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.pms.Entities.PolicyTable;

@Repository
public interface PolicyDataRepo  extends JpaRepository<PolicyTable, String>  {

    @Query(value="select * from policy_table where policy_type=:policy and company_company_id=:compId order by policy_id desc",nativeQuery=true)
    public List<PolicyTable> findregister(@Param ("policy") String policy,@Param ("compId") String compId);
    
    @Query("select count(uep.policy.policyId) from UserEnrolledPolicy uep where uep.user.userid= :userid and uep.policy.policyId like %:var% ")
    public int findNumber(@Param ("userid") String userid, @Param("var") String var);
    //started from here 
    @Query(value="select * from policy_table pt where pt.policy_type =:policyType and pt.company_company_id=:companyId order by pt.policy_id",nativeQuery=true)
	 public List<PolicyTable> findByPolicyTypeandName(@Param ("policyType") String policyType,@Param ("companyId") String companyId);

  //  @Query(value="select * from  policy_table p where p.company_company_id= :companyId and   p.policy_type like :policyType% and  p.duration= :years and p.policy_name= :policyName ",nativeQuery=true)
    @Query("select p from  PolicyTable p where p.company.companyId= :companyId and p.policyType = :policyType and p.duration = :years ")
    public List<PolicyTable> searchPolicy(@Param ("companyId") String companyId,@Param ("years") int years,@Param ("policyType") String policyType);

    
    @Query(value="SELECT pt.policy_type FROM user_enrolled_policy uep join policy_table pt on uep.policy_policy_id = pt.policy_id where uep.user_user_id=:userid group by  uep.user_user_id,pt.policy_type having count(pt.policy_type) =2",nativeQuery=true)
    public List<String> searchUserPolicy1(@Param ("userid") String userid);
    
    @Query("select pt from PolicyTable pt where pt.policyType not in (:list)")
    public List<PolicyTable> searchUserPolicy2(@Param ("list") List<String> list);
    
    @Query("Select pt from PolicyTable pt where pt.policyName like :polName% ")
    public List<PolicyTable> searchUserByPolicyName(@Param ("polName") String polName);
	
    public PolicyTable findByPolicyId(String policyId);
	
	public List<PolicyTable> findByPolicyType(String policyType);
	
	@Query(value="select * from policy_table p where p.policy_id=:policy",nativeQuery=true)
	PolicyTable findPolicyTerm(String policy);
	@Query(value="select p.policy_name from Policy_Table p where p.policy_id=:policy",nativeQuery=true)
	String getpolicyname(String policy);
	@Query(value="select p.term_amount from policy_table p where p.policy_id=:policyid",nativeQuery=true)
	public int findPolicyTermAmount(String policyid);
	@Query(value="select p.terms_per_year from policy_table p where p.policy_id=:policyid",nativeQuery=true)
	public int findPolicyYears(String policyid);
    //sort recent
	//@Query("select pt from PolicyTable pt order by pt.startDate DESC limit 4")
    public List<PolicyTable> findTop4ByOrderByStartDateDesc();
    
}