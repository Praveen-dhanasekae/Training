import { Component, OnInit,Output,EventEmitter } from '@angular/core';
import { searchPolicy } from '../interfaces';
import { SearchingService } from '../searching.service';
import { PolicymappingService } from '../policymapping.service';
@Component({
  selector: 'app-user-interface',
  templateUrl: './user-interface.component.html',
  styleUrls: ['./user-interface.component.css'],
  providers:[SearchingService]
})
export class UserInterfaceComponent implements OnInit {
  duration:String;
  companyName:String;
  policyType:String;
  PID:String;
  policyName:String;
  object1:string[];
  objs:object;
  userid:string;
  constructor(private services: SearchingService,private ser:PolicymappingService) { }
   
  result=false;
  @Output()
  out = new EventEmitter();
  SearchPolicy(){
    
    const searchPoli : searchPolicy={
      duration:this.duration,
      company:{"companyId":this.companyName},
      policyType:this.policyType,
    
      policyName:this.policyName
    }
  
 this.services.searching(searchPoli,this.userid).subscribe((response)=>{
   this.object1 = response as string[];
   this.out.emit(this.object1); 
   this.result=true;
   console.log(this.object1);
 });


  }

  ngOnInit() {
    this.ser.companyName().subscribe((response) => {
      this.objs = response;
      console.log(this.objs);
    })

  this.userid =  sessionStorage.getItem('key');
  }

}
