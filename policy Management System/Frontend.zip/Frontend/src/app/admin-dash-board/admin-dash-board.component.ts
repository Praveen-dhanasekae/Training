import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { Router,ActivatedRoute } from '@angular/router';
declare var koopudu: any;

@Component({
  selector: 'app-admin-dash-board',
  templateUrl: './admin-dash-board.component.html',
  styleUrls: ['./admin-dash-board.component.css']
})
export class AdminDashBoardComponent implements OnInit {
  id:string;
  userIds:string;
  constructor(public authService: AuthService,private router:Router,private route:ActivatedRoute) { }

  ngOnInit() {
    this.id = localStorage.getItem('token')
    this.userIds = this.route.snapshot.paramMap.get('userId');
    new koopudu();
  }
  
  logout(){
    console.log("Logout");
    this.authService.logout();
    this.router.navigate(['Signin'])
   }
   create(){
     this.router.navigate(['PolicyRegister',this.userIds]);
   }
   edit(){
     console.log("hi");
     this.router.navigate(['EditPolicy',this.userIds]);
   }
}
