import { Component, OnInit } from '@angular/core';
import { editPolicy } from '../interfaces';
import { EditService } from '../edit.service';
import * as $ from 'jquery';
import swal from 'sweetalert';
import { ActivatedRoute } from '@angular/router';
import { PolicymappingService } from '../policymapping.service';

@Component({
  selector: 'app-edit-policy',
  templateUrl: './edit-policy.component.html',
  styleUrls: ['./edit-policy.component.css'],
  providers:[EditService]
})
export class EditPolicyComponent implements OnInit {
  policyName:string;
  duration:string;
  startDate:string;
  policyType:string;
  termAmount:string;
  edit:string;
  intialDeposit:string;
  companyName:string;
  type:object;
  type1:string;
  maturityAmount:string;
  termsPerYear:string;
  interest:string;
  policyID1:string;
  policyTable:any=[];
  company:object;
  comp:string;
  present = false;
  companys:object;
  search:object;
  value=false;
  userId:string;
  objs:object;
  policyId:string;
  constructor(private services:EditService,private router:ActivatedRoute,private ser:PolicymappingService) { }
  
  fetch(p,i){
    console.log(p);
    var a = (2*(p-1))+i;
     this.policyID1 = this.search[a].policyId;
    
    if(this.policyID1!=undefined || this.policyID1 != null || (this.policyID1)){
       console.log("------"+this.policyID1+"--------");
    this.services.fetching(this.policyID1).subscribe((response)=>{
      this.policyTable = response;
      this.policyId=this.policyTable['policyId'];
      this.policyName = this.policyTable['policyName'];
      this.duration = this.policyTable['duration'];
      this.startDate = this.policyTable['startDate'];
      this.policyType = this.policyTable['policyType'];
      this.termAmount = this.policyTable['termAmount'];
      this.intialDeposit = this.policyTable['intialDeposit'];
      this.type1 = this.policyTable['type1'];
      this.interest = this.policyTable['interest'];
      this.maturityAmount = this.policyTable['maturityAmount'];
      this.termsPerYear = this.policyTable['termsPerYear'];
      this.comp = this.policyTable['comp'];
      if(this.policyTable["message"]== null){
      
        console.log(this.policyTable);
        this.present = true;
        }
        else{
          swal("Sorry..!",this.policyTable['message'],"error");
          this.present = false;
          console.log(this.policyID1);
        }
        
     })
    
     
    }else{
      swal("Sorry","Please enter the PolicyId","error");
      console.log(this.policyID1);
    }
    $("button").click(function() {
      $('html,body').animate({
          scrollTop: $(".third").offset().top},
          'slow');
  });
  //  console.log(this.policyID1);

 this.value = true;
  }
  EditPolicy(){

    const editPoll : editPolicy = {
      policyName:this.policyName,
      duration:this.duration,
      startDate:this.startDate,
      policyType:this.policyType,
      termAmount:this.termAmount,
      intialDeposit:this.intialDeposit,
       type:{"typeid":this.type1},
      interest:this.interest,
      termsPerYear:this.termsPerYear,
      maturityAmount:this.maturityAmount,
      company:{"companyId":this.comp}

    }
    this.services.Editpolicy(editPoll,this.userId).subscribe((response)=>{
      this.edit = response;
      if(this.edit.substring(0,3) === "The"){
      swal("Success",this.edit,"success");}
      else{
        swal("Sorry..!",this.edit,"error");
      }
      console.log(this.edit);
    })

    
  }
  SearchPolicy(){
    const obj = {
         company :{ "companyId":this.companyName},
         policyName:this.policyName,
         policyType:this.policyType,
         duration:this.duration
    }
    console.log(obj);
    this.services.searching(obj).subscribe((resp)=>{
      console.log(resp);
      this.search = resp;
    })
   
  }
  ngOnInit() {
    $("button").click(function() {
      $('html,body').animate({
          scrollTop: $(".second").offset().top},
            
          'slow');
  });
  this.userId = this.router.snapshot.paramMap.get('userId');
  this.ser.companyName().subscribe((response) => {
    this.objs = response;
    console.log(this.objs);
  })
  }
  

}
