import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EditService {

  constructor(private http: HttpClient) { }
  fetching(strin){
    return this.http.get("http://10.230.174.247:1214/returnPolicyId/"+""+strin);
    }
  
  Editpolicy(editobj,user){
    console.log("ser"+user);
    return this.http.put("http://10.230.174.247:1214/editregisteredPolicy/"+""+user+"/",editobj,{responseType:'text' as 'text'});
  }
  searching(obj){
    return this.http.post("http://10.230.174.247:1214/searchingPolicy/",obj)
  }
}
