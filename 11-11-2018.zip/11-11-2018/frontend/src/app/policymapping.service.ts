import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {policyRegisterses} from '../app/interfaces'
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class PolicymappingService {

  constructor(private https:HttpClient) { }
  policyRegistering(obj:any){
   return this.https.post("http://localhost:1214/registeringPolicy/",obj,{responseType:'text' as 'text'});
  }
}
