export class userRegister  {

    firstName:string;
    lastName:String;
    dob:String;
    address:String;
    contactNo:String;
    emailId:String;
    qualification:String;
    salary:String;
    panNo:String;
    employerType:String;
   gender:string;
   hint:any;
   hintid:number;
   hintans:String;
    employer:String;
}

export class policyRegisterses{
    policyName:String;
    startDate:String;
    duration:String;
    intialDeposit:String;
    t:String;
   
   t1:String;
   policyType:string;
   termsPerYear:String;
   termAmount:String; 
   interest:String;
}

export class editPolicy{
    policyName:String;
    duration:String;
    PType:String;
    termAmount:String;
    
}

export class searchPolicy{
    duration:String;
    company:String;
    policy_type:String;
    PID:String;
    policy_name:String;
}

export class UserAdmin{
    user :String;
    pass:String;
}