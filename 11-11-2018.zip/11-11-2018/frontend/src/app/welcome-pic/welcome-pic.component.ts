import { Component, OnInit, AfterViewInit } from '@angular/core';
declare var $:any;
@Component({
  selector: 'app-welcome-pic',
  templateUrl: './welcome-pic.component.html',
  styleUrls: ['./welcome-pic.component.css']
})
export class WelcomePicComponent implements OnInit,AfterViewInit {

  constructor() { }
 
  ngOnInit() {
  }

  ngAfterViewInit(){
    
  
  }
}
