import { Component, OnInit } from '@angular/core';
import {UserInterfaceComponent} from '../user-interface/user-interface.component';
import { Router } from '@angular/router';
import { AdminDashBoardComponent } from '../admin-dash-board/admin-dash-board.component';
import { UserAdmin } from '../interfaces';
import { SigninService } from '../signin.service';
import swal from 'sweetalert';
@Component({
  selector: 'app-user-sign-in-page',
  templateUrl: './user-sign-in-page.component.html',
  styleUrls: ['./user-sign-in-page.component.css'],
  providers:[SigninService]
})
export class UserSignInPageComponent implements OnInit {
  
 
  user:String;
  pass:String;
  public books;
  public ListOfPolicy:any[]; 
  public USER:string;
  public PASS:string;
  constructor(private router:Router,private service:SigninService) { }
  validation(){
    const userAdmin: UserAdmin = {
      user:this.user,
      pass:this.pass
    }
   this.service.posting(userAdmin).subscribe((response) => {
     this.books = response;
   //console.log(JSON.stringify(this.books));
  /*this.USER = this.books["user"];
   this.PASS = this.books["pass"];
   this.val(this.USER,this.PASS);
*/
console.log(this.books);
this.val(this.books,this.user)
   });
  
    
  }
val(a,userID){
console.log(userID);
if(a === "authenticated" && userID == "admin"){
  this.router.navigate(["AdminDash"]);
 }else if(a=== "authenticated"){
  this.service.sendParams(userID).subscribe((response) => {
    console.log(response);
  });
   this.router.navigate(['Uinter']);
 }
 else{
   swal("Sorry...!",this.books,"error");
 }
}
  ngOnInit() {
    
  }

}
