import { Component, OnInit } from '@angular/core';
import { policyRegisterses } from '../interfaces';

import { Router } from '@angular/router';
import { PolicymappingService } from '../policymapping.service';

@Component({
  selector: 'app-policy-register',
  templateUrl: './policy-register.component.html',
  styleUrls: ['./policy-register.component.css'],
  providers:[PolicymappingService]
})
export class PolicyRegisterComponent implements OnInit {
  policyName: String;
  startDate: String;
  duration: String;
  intialDeposit: String;
  t: String;
 
  t1: String;
  policyType:string;
  termsPerYear: String;
  termAmount: String;
  interest: String;
  val:string;

  constructor(private services:PolicymappingService,private route:Router) { }
  
  PolicyRegister() {
    const policyRegis: policyRegisterses = {
      policyName: this.policyName,
      startDate: this.startDate,
      duration: this.duration,
      intialDeposit: this.intialDeposit,
      t: this.t,
     
      policyType:this.policyType,
      t1: this.t1,
      termsPerYear: this.termsPerYear,
      termAmount: this.termAmount,
      interest: this.interest
    }
    this.services.policyRegistering(policyRegis).subscribe((response)=> {
      this.val = response;
    console.log(this.val);
    })
   
  }
  ngOnInit() {
  }

}
