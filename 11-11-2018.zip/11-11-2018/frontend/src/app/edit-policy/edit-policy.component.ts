import { Component, OnInit } from '@angular/core';
import { editPolicy } from '../interfaces';

@Component({
  selector: 'app-edit-policy',
  templateUrl: './edit-policy.component.html',
  styleUrls: ['./edit-policy.component.css']
})
export class EditPolicyComponent implements OnInit {
  policyName:String;
  duration:String;
  PType:String;
  termAmount:String;

  constructor() { }

  EditPolicy(){
    const editPoll : editPolicy = {
      policyName:this.policyName,
      duration:this.duration,
      PType:this.PType,
      termAmount:this.termAmount
    }
    //console.log(this.Pname+"-----"+this.DIY+"------"+this.PType+"--------"+this.TAmount);
  }
  ngOnInit() {
  }

}
