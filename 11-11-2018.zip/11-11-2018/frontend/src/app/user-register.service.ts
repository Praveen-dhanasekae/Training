import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { userRegister } from '../app/interfaces';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class UserRegisterService {

  constructor(private http:HttpClient) { }

  storeData(data){
    return this.http.post("http://localhost:1214/register/",data,{responseType:'text' as 'text'});
  }

}
