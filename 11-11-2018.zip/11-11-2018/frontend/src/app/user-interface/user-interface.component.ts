import { Component, OnInit } from '@angular/core';
import { searchPolicy } from '../interfaces';

@Component({
  selector: 'app-user-interface',
  templateUrl: './user-interface.component.html',
  styleUrls: ['./user-interface.component.css']
})
export class UserInterfaceComponent implements OnInit {
  duration:String;
  company:String;
  policy_type:String;
  PID:String;
  policy_name:String;
  constructor() { }

  SearchPolicy(){
    const searchPoli : searchPolicy={
      duration:this.duration,
      company:this.company,
      policy_type:this.policy_type,
      PID:this.PID,
      policy_name:this.policy_name
    }
  }

  ngOnInit() {
  }

}
