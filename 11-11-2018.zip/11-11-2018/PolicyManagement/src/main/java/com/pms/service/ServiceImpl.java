package com.pms.service;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pms.Entities.Company;
import com.pms.Entities.Hint;
import com.pms.Entities.LoginObject;
import com.pms.Entities.Mainuser;
import com.pms.Entities.PolicyTable;
import com.pms.Entities.Usertype;
import com.pms.dao.MainDataRepo;
import com.pms.dao.PolicyDataRepo;
@Service
public class ServiceImpl implements Service1{

	// Register and Login 
	
	@Autowired
    private MainDataRepo dao1;
    com.pms.Entities.Mainuser name;
	@Autowired
	private PolicyDataRepo dao2;
    
	DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	@Override
	public String authenticate(LoginObject log) {
		       
		       name=null;
		       String mess="";
		       name= dao1.findByName(log.getUser());
		       if(name!=null) {
		       if(name.getPasscode().equals(log.getPass()))
		    	  mess="authenticated";
		       else
		    	  mess="incorrect password ";
		       }
		       else mess="User not found";
		       
		    	return mess;			
	}
	@Override
	public String registerUser(Mainuser user) {
		Calendar cal=Calendar.getInstance();
		name=null;List<Mainuser> test=null;
		String b="",mess="";
		name=dao1.findByPanNoAndEmaiId(user.getPanNo(), user.getEmailId());
		System.out.println("user id "+user.getAddress() +" passcode ");
		double a=user.getSalary();
		System.out.println("before salary");
		if(a<=5) b="A";
		else if(a<=10) b="B";
		else if(a<=15) b="C";
		else if(a<=20) b="D";
		else if(a<=25) b="E";
		else if(a<=30 || a>30) b="F";
		System.out.println("before if");
		if(name==null) {
			System.out.println("after if");
			//String str = String.format("%04d", 9);
			test= dao1.findByUseridStartingWithOrderByUseridDesc(b);
			System.out.println("after func");
			String[] val=test.get(0).getUserid().split("-");
			user.setUserid(b+"-"+String.format("%03d",(Integer.parseInt(val[1])+1)));
			String pass=""+(new SimpleDateFormat("dd").format(cal.getTime()))+(new SimpleDateFormat("MMM").format(cal.getTime())).toLowerCase()+""
			                      +((new Random().nextInt(998-100))+100)+"";
			System.out.println("after passcode");
			user.setPasscode(pass);
			Hint t=new Hint();
			
 			t.setHintId(user.getHintid());
     //	     System.out.println(user.getAddress());
			user.setHint(t);
			dao1.saveAndFlush(user);
			mess="The user id is "+user.getUserid()+" and password "+user.getPasscode();
		}
		else
		mess="Sorry ..! PAN Number or the EMAIL ID already exists or are not valid. Please Check for the credentials";
		
	return mess;
	}
	
	public String registerPolicy(PolicyTable obj) {
		
		
		//Checks Start Date VAlidation
		LocalDate today =  LocalDate.now(); 
		LocalDate date = obj.getStartDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
	    if(today.isBefore(date)) return "Start date is not correct please redefine the policy";
		System.out.println(obj.getPolicyType());
	    // Save the object with required values. 
	    List<PolicyTable> tab1= dao2.findByPolicyTypeOrderByPolicyIdDesc(obj.getPolicyType());
		String[] val=tab1.get(0).getPolicyId().split("-");
		obj.setPolicyId(val[0]+"-"+val[1]+"-"+(Integer.parseInt(val[2])+1));
		Company t=new Company();
		t.setCompanyId(obj.getCompId());
		Usertype t1=new Usertype();
		t1.setTypeid(obj.getT1());
		obj.setCompany(t);
		obj.setType(t1);
		dao2.save(obj);
		date.plusYears(obj.getDuration());
		//Maturity amount = (initial deposit) + (duration * term_in_years * term amount) + ((duration * term_in_years * term amount) * (interest /100))
		return "   The policy"+ obj.getPolicyId() +"is available to the users from "+ obj.getStartDate() +" to"+ date.format(dateTimeFormatter) +
				"This is the"+ (val[2]+1) +"th policy in the "+ obj.getPolicyType();
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
  // Policy Registration 
}
