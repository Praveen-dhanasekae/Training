import { Component, OnInit} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ConformSerService } from '../conform-ser.service';

@Component({
  selector: 'app-conform-page',
  templateUrl: './conform-page.component.html',
  styleUrls: ['./conform-page.component.css'],
  providers:[ConformSerService]
})
export class ConformPageComponent implements OnInit {
  val1:string;
  val2:string;
  objects:any;
  obj:any=[];
  result=false;
  gowtham:any=[];
  constructor(private route:ActivatedRoute,private ser: ConformSerService) { }
  
  ngOnInit() { 
    this.val1 = this.route.snapshot.paramMap.get('policyIds');
    this.val2 = this.route.snapshot.paramMap.get('userid');
    this.objects = {
      user:this.val2,
      policy:this.val1
    }
    this.ser.SendKeer(this.objects).subscribe((response) => {
      this.obj = response;
      this.gowtham = this.obj;
      console.log(this.obj);
       
    })
  }

  callPay(){
  this.result = true;
 
}


     
}
