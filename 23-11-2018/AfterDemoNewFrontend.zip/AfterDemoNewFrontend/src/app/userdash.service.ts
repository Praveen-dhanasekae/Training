import { Injectable } from '@angular/core';
import { HttpClient,HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class UserdashService {
a:any;
  constructor(private http:HttpClient) { }

  sendParams(UserID){
    let val = new HttpParams().set("userid",UserID)
   // console.log(val);
   this.a = this.http.get("http://10.230.174.247:1214/we/",{params:val});
    // return this.http.get("http://10.230.174.247:1214/we/",{params:val});
    return this.a;
   
  }
  
  scrollBar(){
    return this.http.get("http://10.230.174.247:1214/searchRecent/")
  }

}
