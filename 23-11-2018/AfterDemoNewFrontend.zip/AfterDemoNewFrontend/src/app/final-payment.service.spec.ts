import { TestBed } from '@angular/core/testing';

import { FinalPaymentService } from './final-payment.service';

describe('FinalPaymentService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FinalPaymentService = TestBed.get(FinalPaymentService);
    expect(service).toBeTruthy();
  });
});
