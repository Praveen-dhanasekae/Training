import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';
declare var koopudu: any;

@Component({
  selector: 'app-admin-dash-board',
  templateUrl: './admin-dash-board.component.html',
  styleUrls: ['./admin-dash-board.component.css']
})
export class AdminDashBoardComponent implements OnInit {
  id:string;
  
  constructor(public authService: AuthService,private router:Router) { }

  ngOnInit() {
    this.id = localStorage.getItem('token')
    
    new koopudu();
  }
  
  logout(){
    console.log("Logout");
    this.authService.logout();
    this.router.navigate(['Signin'])
   }
}
