import { Component, OnInit } from '@angular/core';
declare var koopudu: any;
@Component({
  selector: 'app-admin-dash-board',
  templateUrl: './admin-dash-board.component.html',
  styleUrls: ['./admin-dash-board.component.css']
})
export class AdminDashBoardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    new koopudu();
  }

}
